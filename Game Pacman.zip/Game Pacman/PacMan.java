import java.awt.*;
import java.awt.event.*;
import java.util.HashSet;
import java.util.Random;
import javax.swing.*;

public class PacMan extends JPanel implements ActionListener, KeyListener {
    class Block {
        int x, y, width, height;
        int startX, startY, velocityX = 0, velocityY = 0;

        char direction = 'U'; // U D L R
        Image image;

        Block(Image image, int x, int y, int width, int height) {
            this.image = image;
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.startX = x;
            this.startY = y;
        }

        void updateDirection(char newDirection) {
            char prevDirection = this.direction;
            updatePosition(newDirection);
        
            if (isCollidingWithWalls()) {
                revertPosition();
                revertDirection(prevDirection);
            }
        }
        
        void updatePosition(char newDirection) {
            this.direction = newDirection;
            updateVelocity();
        
            this.x += this.velocityX;
            this.y += this.velocityY;
        }
        
        void revertPosition() {
            this.x -= this.velocityX;
            this.y -= this.velocityY;
        }
        
        void revertDirection(char prevDirection) {
            this.direction = prevDirection;
            updateVelocity();
        }
        
        boolean isCollidingWithWalls() {
            for (Block wall : walls) {
                if (collision(this, wall)) {
                    return true;
                }
            }
            return false;
        }
        
        void updateVelocity() {
            switch (this.direction) {
                case 'U':
                    this.velocityX = 0;
                    this.velocityY = -tileSize / 4;
                    break;
                case 'D':
                    this.velocityX = 0;
                    this.velocityY = tileSize / 4;
                    break;
                case 'L':
                    this.velocityX = -tileSize / 4;
                    this.velocityY = 0;
                    break;
                case 'R':
                    this.velocityX = tileSize / 4;
                    this.velocityY = 0;
                    break;
                default:
                    this.velocityX = 0;
                    this.velocityY = 0; // Optional: Handle unexpected directions
                    break;
            }
        }
        void reset() {
            this.x = this.startX;
            this.y = this.startY;
        }
    }

    private int rowCount = 21, columnCount = 19, tileSize = 32;
    private int boardWidth = columnCount * tileSize;
    private int boardHeight = rowCount * tileSize;

    private Image wallImage, blueGhostImage, orangeGhostImage, pinkGhostImage, redGhostImage;
    private Image pacmanUpImage, pacmanDownImage, pacmanLeftImage, pacmanRightImage;

    //X = wall, O = skip, P = pac man, ' ' = food
    //Ghosts: b = blue, o = orange, p = pink, r = red
    private String[] tileMap = {
        "XXXXXXXXXXXXXXXXXXX",
        "X        X        X",
        "X XX XXX X XXX XX X",
        "X                 X",
        "X XX X XXXXX X XX X",
        "X    X       X    X",
        "XXXX XXXX XXXX XXXX",
        "OOOX X       X XOOO",
        "XXXX X XXrXX X XXXX",
        "X       bpo       X",
        "XXXX X XXXXX X XXXX",
        "OOOX X       X XOOO",
        "XXXX X XXXXX X XXXX",
        "X        X        X",
        "X XX XXXXXXXXX XX X",
        "X  X     P     X  X",
        "XX X X XXXXX X X XX",
        "X    X   X   X    X",
        "X XXXXXXXXXXXXXXX X",
        "X                 X",
        "XXXXXXXXXXXXXXXXXXX" 
    };

    HashSet<Block> walls, foods, ghosts;
    Block pacman;

    Timer gameLoop;
    char[] directions = {'U', 'D', 'L', 'R'}; //up down left right
    Random random = new Random();
    int score = 0;
    int lives = 3;
    boolean gameOver = false;

    PacMan() {
        setPreferredSize(new Dimension(boardWidth, boardHeight));
        setBackground(Color.BLACK);
        addKeyListener(this);
        setFocusable(true);

        //load images
        wallImage = new ImageIcon(getClass().getResource("./wall.png")).getImage();
        blueGhostImage = new ImageIcon(getClass().getResource("./blueGhost.png")).getImage();
        orangeGhostImage = new ImageIcon(getClass().getResource("./orangeGhost.png")).getImage();
        pinkGhostImage = new ImageIcon(getClass().getResource("./pinkGhost.png")).getImage();
        redGhostImage = new ImageIcon(getClass().getResource("./redGhost.png")).getImage();

        pacmanUpImage = new ImageIcon(getClass().getResource("./pacmanUp.png")).getImage();
        pacmanDownImage = new ImageIcon(getClass().getResource("./pacmanDown.png")).getImage();
        pacmanLeftImage = new ImageIcon(getClass().getResource("./pacmanLeft.png")).getImage();
        pacmanRightImage = new ImageIcon(getClass().getResource("./pacmanRight.png")).getImage();

        loadMap();
        for (Block ghost : ghosts) {
            char newDirection = directions[random.nextInt(4)];
            ghost.updateDirection(newDirection);
        }
        //how long it takes to start timer, milliseconds gone between frames
        gameLoop = new Timer(50, this); //20fps (1000/50)
        gameLoop.start();

    }

    public void loadMap() {
        walls = new HashSet<>();
        foods = new HashSet<>();
        ghosts = new HashSet<>();
    
        for (int r = 0; r < rowCount; r++) {
            String row = tileMap[r];
            for (int c = 0; c < columnCount; c++) {
                char tileChar = row.charAt(c);
                int x = c * tileSize;
                int y = r * tileSize;
    
                processTile(tileChar, x, y);
            }
        }
    }
    
    private void processTile(char tileChar, int x, int y) {
        switch (tileChar) {
            case 'X': // Wall
                walls.add(new Block(wallImage, x, y, tileSize, tileSize));
                break;
            case 'b': // Blue ghost
                addGhost(blueGhostImage, x, y);
                break;
            case 'o': // Orange ghost
                addGhost(orangeGhostImage, x, y);
                break;
            case 'p': // Pink ghost
                addGhost(pinkGhostImage, x, y);
                break;
            case 'r': // Red ghost
                addGhost(redGhostImage, x, y);
                break;
            case 'P': // Pacman
                pacman = new Block(pacmanRightImage, x, y, tileSize, tileSize);
                break;
            case ' ': // Food
                foods.add(new Block(null, x + 14, y + 14, 4, 4));
                break;
            default:
                // Optional: Handle unexpected characters
                break;
        }
    }
    
    private void addGhost(Image ghostImage, int x, int y) {
        ghosts.add(new Block(ghostImage, x, y, tileSize, tileSize));
    }
    
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    public void draw(Graphics g) {
        g.drawImage(pacman.image, pacman.x, pacman.y, pacman.width, pacman.height, null);

        for (Block ghost : ghosts) {
            g.drawImage(ghost.image, ghost.x, ghost.y, ghost.width, ghost.height, null);
        }

        for (Block wall : walls) {
            g.drawImage(wall.image, wall.x, wall.y, wall.width, wall.height, null);
        }

        g.setColor(Color.WHITE);
        for (Block food : foods) {
            g.fillRect(food.x, food.y, food.width, food.height);
        }
        //score
        g.setFont(new Font("Arial", Font.PLAIN, 18));
        if (gameOver) {
            g.drawString("Game Over: " + String.valueOf(score), tileSize/2, tileSize/2);
        }
        else {
            g.drawString("x" + String.valueOf(lives) + " Score: " + String.valueOf(score), tileSize/2, tileSize/2);
        }
    }

    public void move() {
        movePacman();
        handleGhosts();
        handleFoodCollision();
    
        if (foods.isEmpty()) {
            loadMap();
            resetPositions();
        }
    }
    
    private void movePacman() {
        pacman.x += pacman.velocityX;
        pacman.y += pacman.velocityY;
    
        // Check for wall collisions
        if (checkCollisionWithWalls(pacman)) {
            pacman.x -= pacman.velocityX;
            pacman.y -= pacman.velocityY;
        }
    }
    
    private void handleGhosts() {
        for (Block ghost : ghosts) {
            // Check for collision with Pacman
            if (collision(ghost, pacman)) {
                lives -= 1;
                if (lives == 0) {
                    gameOver = true;
                    return;
                }
                resetPositions();
            }
    
            moveGhost(ghost);
        }
    }
    
    private void moveGhost(Block ghost) {
        if (ghost.y == tileSize * 9 && ghost.direction != 'U' && ghost.direction != 'D') {
            ghost.updateDirection('U');
        }
    
        ghost.x += ghost.velocityX;
        ghost.y += ghost.velocityY;
    
        // Check for wall or boundary collisions
        if (checkCollisionWithWalls(ghost) || isOutOfBounds(ghost)) {
            ghost.x -= ghost.velocityX;
            ghost.y -= ghost.velocityY;
    
            char newDirection = directions[random.nextInt(4)];
            ghost.updateDirection(newDirection);
        }
    }
    
    private void handleFoodCollision() {
        Block foodEaten = null;
        for (Block food : foods) {
            if (collision(pacman, food)) {
                foodEaten = food;
                score += 10;
                break; // Pacman can only eat one food at a time
            }
        }
        foods.remove(foodEaten);
    }
    
    private boolean checkCollisionWithWalls(Block block) {
        return walls.stream().anyMatch(wall -> collision(block, wall));
    }
    
    private boolean isOutOfBounds(Block block) {
        return block.x <= 0 || block.x + block.width >= boardWidth;
    }
    
    public boolean collision(Block a, Block b) {
        return a.x < b.x + b.width &&
               a.x + a.width > b.x &&
               a.y < b.y + b.height &&
               a.y + a.height > b.y;
    }
    
    public void resetPositions() {
        resetPacman();
        resetGhosts();
    }
    
    private void resetPacman() {
        pacman.reset();
        pacman.velocityX = 0;
        pacman.velocityY = 0;
    }
    
    private void resetGhosts() {
        for (Block ghost : ghosts) {
            ghost.reset();
            char newDirection = directions[random.nextInt(4)];
            ghost.updateDirection(newDirection);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        move();
        repaint();
        if (gameOver) {
            gameLoop.stop();
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {}

    @Override
    public void keyReleased(KeyEvent e) {
        if (gameOver) {
            loadMap();
            resetPositions();
            lives = 3;
            score = 0;
            gameOver = false;
            gameLoop.start();
        }
        // System.out.println("KeyEvent: " + e.getKeyCode());
        if (e.getKeyCode() == KeyEvent.VK_UP) {
            pacman.updateDirection('U');
        }
        else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            pacman.updateDirection('D');
        }
        else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            pacman.updateDirection('L');
        }
        else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            pacman.updateDirection('R');
        }

        if (pacman.direction == 'U') {
            pacman.image = pacmanUpImage;
        }
        else if (pacman.direction == 'D') {
            pacman.image = pacmanDownImage;
        }
        else if (pacman.direction == 'L') {
            pacman.image = pacmanLeftImage;
        }
        else if (pacman.direction == 'R') {
            pacman.image = pacmanRightImage;
        }
    }
}